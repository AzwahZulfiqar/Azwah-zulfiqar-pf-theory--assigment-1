#include <iostream>
using namespace std;

int main() {
    int model;
    cin >> model;

    if (model == 300)
        cout << "PIP, Stereo, Remote";
    else if (model == 200)
        cout << "Stereo, Remote";
    else if (model == 100)
        cout << "Remote only";
}
