#include <iostream>
using namespace std;

int main() {
    int m, d, y;
    cin >> m >> d >> y;

    if (m * d == y)
        cout << "MAGIC";
    else
        cout << "NOT MAGIC";
}
