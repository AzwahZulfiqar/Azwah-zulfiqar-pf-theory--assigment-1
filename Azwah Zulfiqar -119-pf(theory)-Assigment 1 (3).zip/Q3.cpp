#include <iostream>
using namespace std;

int main() {
    int n1, n2;
    cin >> n1 >> n2;

    if (n1 > n2)
        cout << "Larger: " << n1 << " Smaller: " << n2;
    else if (n2 > n1)
        cout << "Larger: " << n2 << " Smaller: " << n1;
    else
        cout << "Both equal";
}
