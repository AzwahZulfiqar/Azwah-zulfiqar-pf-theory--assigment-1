#include<iostream>
using namespace std;
int main(){
	int x,y;
	cout<<"Enter Value for Y :";
	cin>>y;
	
	if(y==10)
	x=0;
	else
	x=1;
	cout<<"X = "<<x;
	return 0;
}
