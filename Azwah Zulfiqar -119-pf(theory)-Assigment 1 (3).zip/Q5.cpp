#include <iostream>
using namespace std;

int main() {
    double num, den;
    cin >> num >> den;

    if (den != 0)
        cout << "Result: " << num / den;
    else
        cout << "Division by zero is not possible";
}
