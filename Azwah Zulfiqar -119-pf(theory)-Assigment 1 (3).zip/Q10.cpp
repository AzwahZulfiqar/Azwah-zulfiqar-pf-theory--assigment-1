#include <iostream>
using namespace std;

int main() {
    double mass, weight;
    cin >> mass;

    weight = mass * 9.8;
    cout << "Weight: " << weight << endl;

    if (weight > 1000)
        cout << "Too heavy";
    else if (weight < 10)
        cout << "Too light";
}
