#include <iostream>
using namespace std;

int main() {
    int choice, months;
    double rate;

    cin >> choice;

    if (choice == 4) return 0;

    cin >> months;

    if (choice == 1) rate = 40;
    else if (choice == 2) rate = 20;
    else if (choice == 3) rate = 30;

    cout << rate * months;
}
