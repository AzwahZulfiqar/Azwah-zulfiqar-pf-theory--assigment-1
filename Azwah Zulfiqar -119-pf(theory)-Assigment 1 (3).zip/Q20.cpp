#include <iostream>
using namespace std;

int main() {
    int sec;
    cin >> sec;

    if (sec >= 86400)
        cout << "Days: " << sec / 86400;
    else if (sec >= 3600)
        cout << "Hours: " << sec / 3600;
    else if (sec >= 60)
        cout << "Minutes: " << sec / 60;
}
